#! /usr/bin/env python3


def greeting(input_name):
    print('hello,', input_name, 'have a nice day.')

def favorite(input_fav):
    print('my favorite is:', input_fav)

def main():
    print('this is main in say_hello.py')

# set the environment for this script
# is it main, or is this a module being called by another script
if __name__ == '__main__':
    main()