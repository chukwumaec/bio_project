#! /usr/bin/env python3

print("this is just a text file")

